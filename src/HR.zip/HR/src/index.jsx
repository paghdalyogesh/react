import React from 'react'
import ReactDOM from 'react-dom'
import App from './app'
import { createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import { Provider } from 'react-redux'
import * as serviceWorker from './serviceWorker'
import './css/style.css'

import rootReducer from './store/reducers/rootReducer'
const store = createStore(rootReducer, applyMiddleware(thunk));

ReactDOM.hydrate(<Provider store={store}><App /></Provider>, document.getElementById('root'));
serviceWorker.unregister();