
const intialState = {
    error: "",
    webInfo: null,
    webVerify: null,
    webLogin: null,
    webReg: null,
    webForgot: null,
    webPwd: null
}

const headerReducer = (state = intialState, action) => {

    switch (action.type) {
        case "HEADERDATA":
            return { ...state, webInfo: action.data }
        case "LOGINDATA":
            return { ...state, webLogin: action.data }
        case "REGDATA":
            return { ...state, webReg: action.data }
        case "FORGOTDATA":
            return { ...state, webForgot: action.data }
        case "PWDDATA":
            return { ...state, webPwd: action.data }
        case "VERIFYDATA":
            return { ...state, webVerify: action.data }
        case "ERROR":
            return { ...state, error: action.msg }
        default:
            return state
    }
}
export default headerReducer