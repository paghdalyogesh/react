
import Api from "../api"

function resEmail(data){
    if(data.E){
        Api.getCall('auth/EmailTemplate.php?type='+ data.E +'&userID='+ data.userID);
    }
}

export const fetchHeader = () => {
    return (dispatch) => {
        return Api.getCall('auth/website.php')
            .then(response => response.json())
            .then(json => dispatch({ type: "HEADERDATA", data: json }))
            .catch(err => dispatch({ type: "ERROR", msg: "Unable to fetch data" }))
    }
}
export const postLogin = (body) => {
    return (dispatch, getState) => {
        return Api.postCall('auth/login.php', body)
            .then(response => response.json({  }))
            .then(json => dispatch({ type: "LOGINDATA", data: json }, resEmail(json)))
            .catch(err => dispatch({ type: "ERROR", msg: "Unable to fetch data" }))
    }
}
export const postReg = (body) => {
    return (dispatch, getState) => {
        return Api.postCall('auth/registration.php', body)
            .then(response => response.json())
            .then(json => dispatch({ type: "REGDATA", data: json }, resEmail(json)))
            .catch(err => dispatch({ type: "ERROR", msg: "Unable to fetch data" }))
    }
}
export const postForgot = (body) => {
    return (dispatch, getState) => {
        return Api.postCall('auth/forgot-password.php', body)
            .then(response => response.json())
            .then(json => dispatch({ type: "FORGOTDATA", data: json }, resEmail(json)))
            .catch(err => dispatch({ type: "ERROR", msg: "Unable to fetch data" }))
    }
}
export const postPwd = (body) => {
    return (dispatch, getState) => {
        return Api.postCall('auth/change-password.php', body)
            .then(response => response.json())
            .then(json => dispatch({ type: "PWDDATA", data: json }, resEmail(json)))
            .catch(err => dispatch({ type: "ERROR", msg: "Unable to fetch data" }))
    }
}
export const postVerify = (body) => {
    return (dispatch, getState) => {
        return Api.postCall('auth/verify.php', body)
            .then(response => response.json())
            .then(json => dispatch({ type: "VERIFYDATA", data: json }))
            .catch(err => dispatch({ type: "ERROR", msg: "Unable to fetch data" }))
    }
}