import Cookies from 'universal-cookie'
const cookies = new Cookies();
//const userID = cookies.get('userID');
const auth = cookies.get('auth');

const API_BASE_ADDRESS = '/v1/';
export default class Api {
    static getCall(api) {
        const uri = API_BASE_ADDRESS + api;
        return fetch(uri, {
            method: 'GET',
            headers: new Headers({
                'Authorization': auth, 
                'key': 'XRorSPF4k6AHa4rdcQ90ZgAAAAU', 
                'Content-Type': 'application/json'
              })
        })
    }
    static postCall(api, data) {
        const uri = API_BASE_ADDRESS + api;
        return fetch(uri, {
            method: 'POST',
            body: JSON.stringify(data),
            headers: new Headers({
                'Authorization': auth, 
                'key': 'XRorSPF4k6AHa4rdcQ90ZgAAAAU', 
                'Content-Type': 'application/json'
              })
        });
    }
}