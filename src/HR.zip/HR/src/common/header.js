import React from 'react'
import { Link } from 'react-router-dom'
import Cookies from 'universal-cookie'
import { api } from '../config'
import { connect } from 'react-redux'
import { fetchHeader } from '../store/actions/headerActions'

class Header extends React.Component {

  userWebSetting(webID) {
    const cookies = new Cookies();
    cookies.set('webId', webID, { path: '/' });
  }
  componentWillMount() {
    if (this.props.webInfo === null) {
      this.props.onFetchData();
    }
  }
  render() {
    const { error, webInfo } = this.props;
    const cookies = new Cookies();
    let userID = cookies.get('userID');
    let logoutbtn;
    if (userID) {
      logoutbtn = <Link className="nav-link  text-white" to={'/log-out'}><i className="fa  fa-sign-out icon32" aria-hidden="true"></i><label className="menuLabel d-none d-md-block">Hi</label></Link>
    } else {
      logoutbtn = <Link className="nav-link  text-white" to={'/login'}><i className="fa fa-sign-in icon32" aria-hidden="true"></i><label className="menuLabel d-none d-md-block">Login</label></Link>
    }

    if (error) {
      return <div>Error: {error.message}</div>;
    } else {
      return (
        <header className="bg-info">
          <div className="container">
            <div className="d-flex flex-column flex-md-row align-items-center">
              <h5 className="my-0 mr-md-auto font-weight-normal"><a className="text-white" href={'/'}><h5><i className="fa fa-globe icon32"></i> {webInfo && webInfo.webLogo}</h5></a></h5>
              <nav className="my-2 my-md-0 mr-md-3">
                <ul className="nav">
                  <li className="nav-item">
                    <a className="nav-link active text-white" href={'/'}>
                      <i className="fa fa-home icon32"></i>
                      <label className="menuLabel d-none d-md-block">Jobs</label>
                    </a>
                  </li>
                  {/* userID && <li className="nav-item">
                    <a className="nav-link  text-white" href={api.uiPeople}>
                      <i className="fa fa-user-circle icon32"></i>
                      <label className="menuLabel d-none d-md-block">Users</label>
                    </a>
                  </li> */}
                  {userID && <li className="nav-item">
                    <a className="nav-link  text-white" href={api.uiPeople + 'report'}>
                      <i className="fa fa-sellsy icon32"></i>
                      <label className="menuLabel d-none d-md-block">Report</label>
                    </a>
                  </li>}
                  {userID && <li className="nav-item">
                    <a className="nav-link  text-white" href={api.uiPeople + '/myprofile'}>
                      <i className="fa fa-user icon32"></i>
                      <label className="menuLabel d-none d-md-block">Me</label>
                    </a>
                  </li>}
                  <li className="nav-item">
                    <a className="nav-link  text-white" href={api.uiJob + 'postjob'}>
                      <i className="fa fa-plus-circle icon32"></i>
                      <label className="menuLabel d-none d-md-block">Post Jobs</label></a>
                  </li>
                  <li className="nav-item">
                    {logoutbtn}
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </header>
      );
    }
  }
}

const mapStatetoProps = (state) => {
  return { webInfo: state.headerReducer.webInfo, error: state.error, }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onFetchData: (q) => dispatch(fetchHeader())
  }
}

export default connect(mapStatetoProps, mapDispatchToProps)(Header);
