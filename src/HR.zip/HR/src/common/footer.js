import React from 'react'
import Cookies from 'universal-cookie'
import ReactGA from 'react-ga'
const cookies = new Cookies();
ReactGA.initialize('UA-140663137-1', {
  gaOptions: {
    userId: cookies.get('userID')
  }
});
ReactGA.pageview(window.location.pathname + window.location.search);

class Footer extends React.Component {
  render() {
    return (
      <footer className="footer bg-info border-top">
        <div className="container bottom_border">
          <div className="row">
            <div className=" col-sm-4 col-md col-sm-4  col-12 col">
              <h3 className="headin5_amrc col_white_amrc pt2">Your search is over</h3>
              <p className="mb10">Create an account and let us do the work for you. Once you've signed up, we'll recommend the perfect job for you based on your preferences.</p>
              <p><i className="fa fa fa-envelope"></i> info@paghd.com  </p>
            </div>
            <div className="col-md-6 col-sm-6">
              <h3 className="headin5_amrc col_white_amrc pt2">Be the first to apply</h3>
              <p>Don't miss out on the latest opportunities. Set up a job alert and the jobs that match your preferences will be sent straight to your inbox. That way, you can be the first to apply!</p>
            </div>
          </div>
        </div>
        <div className="container">
          <ul className="foote_bottom_ul_amrc">
            <li><a href="https://www.paghd.com">Home</a></li>
            <li><a href="https://www.paghd.com">Job</a></li>
            <li><a href="https://www.paghd.com/people/">People</a></li>
            <li><a href="https://www.paghd.com/postjob">Post Job</a></li>
            <li><a href="https://www.paghd.com/auth/">Login</a></li>
            <li><a rel="noopener noreferrer" target="_blank" href="https://www.paghd.com/page/privacy-policy.html">Privacy Policy</a></li>
            <li><a rel="noopener noreferrer" target="_blank" href="https://www.paghd.com//page/terms-conditions.html">Terms & Conditions</a></li>
          </ul>
          <p className="text-center"> © Copyright 2019-2020 Paghd Job Portal. All Rights Reserved.</p>
          <ul className="social_footer_ul">
            <li><a rel="noopener noreferrer" target="_blank" href="https://www.facebook.com/paghd.job.3"><i className="fa fa-facebook"></i></a></li>
            <li><a rel="noopener noreferrer" target="_blank" href="https://www.paghd.com"><i className="fa fa-twitter"></i></a></li>
            <li><a rel="noopener noreferrer" target="_blank" href="https://www.linkedin.com/in/job-portal-714362187"><i className="fa fa-linkedin"></i></a></li>
            <li><a rel="noopener noreferrer" target="_blank" href="https://www.paghd.com"><i className="fa fa-instagram"></i></a></li>
          </ul>
        </div>
      </footer>
    );
  }
}

export default Footer;
