import React from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import Header from '../common/header'
import Footer from '../common/footer'
import Cookies from 'universal-cookie'

class LogOut extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: true,
      items: []
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  userWebSetting() {
    const cookies = new Cookies();
    cookies.set('userID', '', { path: '/' });
    cookies.set('auth', '', { path: '/' });
    console.log("Get userID - " + cookies.get('userID'));
  }
  componentDidMount() {
    document.title = "Log out";
    this.userWebSetting();
  }
  handleSubmit(event) {
    this.userWebSetting();
    event.preventDefault();
  }

  render() {
    const { error, isLoaded } = this.state;

    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <div className="rows">
          <Header />
          <div className="container">
            <div className="row">
              <h1 className="col-12">Log Out</h1>
              <p className="col-12">If you need help with this account, please check the Help Centre and then contact us if needed.</p>
              <div className="col-6">
                <form className="needs-validation" onSubmit={this.handleSubmit}>
                  <div className="form-group row">
                    <div className="col-sm-10">
                      <Link className="btn btn-primary" to="/auth/login">Login again!</Link>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      );
    }
  }
}
export default connect(null, null)(LogOut);