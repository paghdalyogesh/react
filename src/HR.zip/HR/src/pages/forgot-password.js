import React from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import Header from '../common/header'
import Footer from '../common/footer'
import { postForgot } from '../store/actions/headerActions'

/*import React from 'react';
import { Link } from "react-router-dom";
import { Header } from "../common/header";
import { Footer } from "../common/footer";
import { api } from '../config'; */

class ForgotPassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: true,
      items: [],
      email: ''
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.formFieldChanges = this.formFieldChanges.bind(this);
  }
  componentDidMount() {
    document.title = "forgot password";
  }
  formFieldChanges(event) {
    var change = {};
    change[event.target.name] = event.target.value;
    this.setState(change);
  }
  userIdentify(userDetails) {
    this.props.onPostData(userDetails);
  }
  handleSubmit(event) {
    let userDetails = {
      email: this.state.email
    }
    this.userIdentify(userDetails);
    event.preventDefault();
  }

  render() {
    const { error, webForgot } = this.props; 
    const {  isLoaded } = this.state;
    let alertmsg;
    if (webForgot && webForgot.msg) {
      alertmsg = <div className={webForgot.valid === true ? "alert alert-success" : "alert alert-danger"}>
        {webForgot.msg}
      </div>
    }

    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <div className="rows">
          <Header />
          <div id="login-overlay" className="modal-dialog">
            <h1 className="d-none">Forgot Password</h1>
            <div className="modal-content">
              <div className="modal-header">
                <h4 className="modal-title" id="myModalLabel">Forgot Password</h4>
              </div>
              <div className="modal-body">
                <div className="rows">
                  <div className="col-xs-6">
                    <div className="well">
                      <form className="needs-validation" onSubmit={this.handleSubmit}>
                        <div className="form-group row">
                          <label className="col-sm-3 col-form-label">Email ID</label>
                          <div className="col-sm-9">
                            <input type="email" className="form-control" onChange={this.formFieldChanges} name="email" ref={this.state.email} value={this.state.email} required />
                          </div>
                        </div>
                        <div className="form-group text-center">
                          {alertmsg}
                          <div className="col-sm-12">
                            <button type="submit" className="btn btn-success">Submit</button>
                          </div>
                        </div>
                        <div className="form-group text-center">
                          <div className="col-sm-12">
                            <Link className="btn btn-link" to="/auth/login">Login</Link>
                            <Link className="btn btn-link" to="/auth/registration">Registration</Link>
                            <Link className="btn btn-link" to="/auth/change-password">Change Password</Link>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      );
    }
  }
}
const mapStatetoProps = (state) => {
  return {
    webForgot: state.headerReducer.webForgot, error: state.error
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    onPostData: (a) => dispatch(postForgot(a))
  }
}
export default connect(mapStatetoProps, mapDispatchToProps)(ForgotPassword);
