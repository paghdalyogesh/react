import React from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import Header from '../common/header'
import Footer from '../common/footer'
import { postReg } from '../store/actions/headerActions'

/*import React from 'react';
import { Link } from "react-router-dom";
import { Header } from "../common/header";
import { Footer} from "../common/footer";
import { api } from '../config';*/

class Registration extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: true,
      items: [],
      name: '',
      email: '',
      userNumber: '',
      pwd: ''
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.formFieldChanges = this.formFieldChanges.bind(this);
  }
  componentDidMount() {
    document.title = "Registration";
  }
  formFieldChanges(event) {
    var change = {};
    change[event.target.name] = event.target.value;
    this.setState(change);
  }

  userIdentify(userDetails) {
    this.props.onPostData(userDetails);
  }
  handleSubmit(event) {
    let userDetails = {
      name: this.state.name,
      email: this.state.email,
      userNumber: this.state.userNumber,
      pwd: this.state.pwd
    }
    this.userIdentify(userDetails);
    event.preventDefault();
  }



  render() {
    const { error, webReg } = this.props;
    const { isLoaded } = this.state;
    let alertmsg;
    if (webReg && webReg.msg) {
      alertmsg = <div className={webReg.valid === true ? "alert alert-success" : "alert alert-danger"}>
        {webReg.msg}
      </div>
    }

    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (<div className="rows">
        <Header />
        <div id="login-overlay" className="modal-dialog">
          <h1 className="d-none"> Registration with paghd.com</h1>
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title" id="myModalLabel">Registration</h1>
            </div>
            <div className="modal-body">
              <div className="rows">
                <div className="col-xs-6">
                  <div className="well">
                    <form className="needs-validation" onSubmit={this.handleSubmit}>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Name</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" onChange={this.formFieldChanges} name="name" ref={this.state.name} value={this.state.name} required />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Email</label>
                        <div className="col-sm-9">
                          <input type="email" className="form-control" onChange={this.formFieldChanges} name="email" ref={this.state.email} value={this.state.email} required />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Contact No</label>
                        <div className="col-sm-9">
                          <input type="text" className="form-control" onChange={this.formFieldChanges} name="userNumber" ref={this.state.userNumber} value={this.state.userNumber} required />
                        </div>
                      </div>
                      <div className="form-group row">
                        <label className="col-sm-3 col-form-label">Password</label>
                        <div className="col-sm-9">
                          <input type="password" className="form-control" onChange={this.formFieldChanges} name="pwd" ref={this.state.pwd} value={this.state.pwd} required />
                        </div>
                      </div>
                      <div className="form-group text-center">
                        {alertmsg}
                        <div className="col-sm-12">
                          <button type="submit" className="btn btn-primary">Register</button>
                        </div>
                      </div>
                      <div className="form-group text-center">
                        <div className="col-sm-12">
                          <Link className="btn btn-link" to="/auth/login">Login</Link>
                          <Link className="btn btn-link" to="/auth/forgot-password">Forgot Password</Link>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
      );
    }
  }
}
const mapStatetoProps = (state) => {
  return {
    webReg: state.headerReducer.webReg, error: state.error
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    onPostData: (a) => dispatch(postReg(a))
  }
}
export default connect(mapStatetoProps, mapDispatchToProps)(Registration);