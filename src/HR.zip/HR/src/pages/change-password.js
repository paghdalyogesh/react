import React from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
import Header from '../common/header'
import Footer from '../common/footer'
import { postPwd } from '../store/actions/headerActions'

class ChangePassword extends React.Component {
  constructor(props) {
    super(props);  
    this.state = {
      error: null,
      isLoaded: true,
      items: [],
      email: '',
      oldPwd: '',
      pinCode: '',
      pwd: ''
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.formFieldChanges = this.formFieldChanges.bind(this);
  }
  componentDidMount(){
    document.title = "forgot password";
  }
  formFieldChanges(event) {
    var change = {};
    change[event.target.name] = event.target.value;
    this.setState(change);
  }
  userIdentify(userDetails) {
    this.props.onPostData(userDetails);
  }
  handleSubmit(event) {
    let userDetails = {
      email: this.state.email,
      oldPwd: this.state.oldPwd,
      pinCode: this.state.pinCode,
      pwd: this.state.pwd
    }
    this.userIdentify(userDetails);
    event.preventDefault();
  }

  render() {
    const { error, webPwd } = this.props;
    const { isLoaded } = this.state;
    let alertmsg;
    if (webPwd && webPwd.msg) {
      alertmsg = <div className={webPwd.valid === true ? "alert alert-success" : "alert alert-danger"}>
        {webPwd.msg}
      </div>
    }

    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <div className="rows">
          <Header />
          <div id="login-overlay" className="modal-dialog">
            <h1 className="d-none">Change Password</h1>
            <div className="modal-content">
              <div className="modal-header">
                <h4 className="modal-title" id="myModalLabel">Change Password</h4>
              </div>
              <div className="modal-body">
                <div className="rows">
                  <div className="col-xs-6">
                    <div className="well">
                      <form className="needs-validation" onSubmit={this.handleSubmit}>
                      <div className="form-group row">
                          <label className="col-sm-4 col-form-label">Email ID</label>
                          <div className="col-sm-8">
                            <input type="email" className="form-control" onChange={this.formFieldChanges} name="email" ref={this.state.email} value={this.state.email} required />
                          </div>
                        </div>
                        <div className="row">
                          <label className="col-sm-4 col-form-label">Old Password</label>
                          <div className="col-sm-8">
                            <input type="password" className="form-control" onChange={this.formFieldChanges} name="oldPwd" ref={this.state.oldPwd} value={this.state.oldPwd}  />
                          </div>
                        </div>
                        <div className="row">
                        <label className="col text-center col-form-label">OR</label>
                        </div>
                        <div className="form-group row">
                          <label className="col-sm-4 col-form-label">PIN Number</label>
                          <div className="col-sm-8">
                            <input type="password" className="form-control" onChange={this.formFieldChanges} name="pinCode" ref={this.state.pinCode} value={this.state.pinCode}   />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-sm-4 col-form-label">New Password</label>
                          <div className="col-sm-8">
                            <input type="password" className="form-control" onChange={this.formFieldChanges} name="pwd" ref={this.state.pwd} value={this.state.pwd} required />
                          </div>
                        </div>
                        <div className="form-group text-center">
                          {alertmsg}
                          <div className="col-sm-12">
                            <button type="submit" className="btn btn-success">Submit</button>
                          </div>
                        </div>
                        <div className="form-group text-center">
                          <div className="col-sm-12">
                            <Link className="btn btn-link" to="/auth/login">Login</Link>
                            <Link className="btn btn-link" to="/auth/forgot-password">Forgot Password</Link>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      );
    }
  }
}

const mapStatetoProps = (state) => {
  return {
    webPwd: state.headerReducer.webPwd, error: state.error
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    onPostData: (a) => dispatch(postPwd(a))
  }
}
export default connect(mapStatetoProps, mapDispatchToProps)(ChangePassword);
