import React from 'react'
import { connect } from 'react-redux'
import Cookies from 'universal-cookie'
import Header from '../common/header'
import Footer from '../common/footer'
import Login from '../component/login'

class LoginPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: true
    };
  }

  render() {
    document.title = "Login";
    const { error, isLoaded } = this.state;

    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <div className="rows">
          <Header />
          <Login />
          <Footer />
        </div>
      );
    }
  }
}

export default connect(null,null)(LoginPage);
