let backendHost;
let UIjob;
let UIpeople;
let UIcompany;
const hostname = window && window.location && window.location.hostname;
 
if(hostname === 'localhost') {
  backendHost = 'http://localhost/v1/';
  //backendHost = 'https://www.paghd.com/v1/';
  UIjob = 'http://localhost/';
  UIpeople = 'http://localhost/people/';
  UIcompany = 'http://localhost/company/';
} else {
  backendHost = 'https://www.paghd.com/v1/';
  UIjob = 'https://www.paghd.com/';
  UIpeople = 'https://www.paghd.com/people/';
  UIcompany = 'https://www.paghd.com/company/';
}

export const api = {
  apiRoot: backendHost, 
  uiJob: UIjob,
  uiPeople: UIpeople,
  uiCompany: UIcompany
}

