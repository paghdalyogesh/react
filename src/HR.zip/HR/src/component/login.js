import React from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'
//import { fetchProfile } from '../store/actions/profileActions'
import Cookies from 'universal-cookie'
import { api } from '../config'
import { postLogin } from '../store/actions/headerActions'

import GoogleLogin from 'react-google-login'
import FacebookLogin from 'react-facebook-login'

//https://www.npmjs.com/package/react-google-login 
//local - 388495122825-1gpuspb3nslcv88tijm7355p21va29u8.apps.googleusercontent.com
//stage - 342562917774-o2l9cnfv8uj3csa9lqqmf44lbuhdciae.apps.googleusercontent.com
//https://www.npmjs.com/package/react-facebook-login
//local - 1280070855476158
//stage - 2312267679062709

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: true,
      items: [],
      email: '',
      pwd: ''
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.formFieldChanges = this.formFieldChanges.bind(this);
  }
  componentDidMount() {
    document.title = "Login";
  }
  formFieldChanges(event) {
    var change = {};
    change[event.target.name] = event.target.value;
    this.setState(change);
  }
  userWebSetting(userID, auth) {
    const cookies = new Cookies();
    cookies.set('userID', userID, { path: '/' });
    cookies.set('auth', auth, { path: '/' });
    window.location.href = api.uiJob;
    console.log("redirect " + api.uiJob);
  }
  userIdentify(userDetails) {
    if (userDetails.email !== '') {
      this.props.onPostData(userDetails);
    }
  }
  handleSubmit(event) {
    let userDetails = {
      email: this.state.email,
      pwd: this.state.pwd,
      web: 1
    }
    this.userIdentify(userDetails);
    event.preventDefault();
  }

  responseFacebook = (response) => {
    if (response.email) {
      let userDetails = {
        name: response.name,
        email: response.email,
        profile: '',
        web: 2
      }
      this.userIdentify(userDetails);
    } else {
      console.log(response);
    }
  }
  responseGoogle = (response) => {
    if (response.profileObj !== undefined) {
      let userDetails = {
        name: response.profileObj.name,
        email: response.profileObj.email,
        profile: response.profileObj.imageUrl,
        web: 2
      }
      this.userIdentify(userDetails);
    }

  }

  render() {
    const { error, webLogin } = this.props;
    if (webLogin && webLogin.valid === true && webLogin.userID && webLogin.auth) {
      this.userWebSetting(webLogin.userID, webLogin.auth);
    }
    const { isLoaded } = this.state;
    let alertmsg;
    if (webLogin && webLogin.msg) {
      alertmsg = <div className={webLogin.valid === true ? "alert alert-success" : "alert alert-danger"}>
        {webLogin.msg}
      </div>
    }

    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
         
          <div id="login-overlay" className="modal-dialog">
            <h1 className="d-none"> Login with paghd.com</h1>
            <div className="modal-content">
              <div className="modal-header">
                <h4 className="modal-title" id="myModalLabel">Login</h4>
              </div>
              <div className="modal-body">
                <div className="rows">
                  <div className="col-xs-6">
                    <div className="well">
                      <form className="needs-validation" onSubmit={this.handleSubmit}>
                        <div className="form-group row">
                          <label className="col-sm-2 col-form-label">Email</label>
                          <div className="col-sm-10">
                            <input type="email" className="form-control" onChange={this.formFieldChanges} name="email" ref={this.state.email} value={this.state.email} required />
                          </div>
                        </div>
                        <div className="form-group row">
                          <label className="col-sm-2 col-form-label">Password</label>
                          <div className="col-sm-10">
                            <input type="password" className="form-control" onChange={this.formFieldChanges} name="pwd" ref={this.state.pwd} value={this.state.pwd} required />
                          </div>
                        </div>

                        <div className="form-group text-center">
                          {alertmsg}
                          <div className="col-sm-12">
                            <button type="submit" className="btn btn-primary">Sign in</button>
                          </div>
                        </div>
                        <div className="form-group rows  text-center">
                          <GoogleLogin
                            clientId="342562917774-o2l9cnfv8uj3csa9lqqmf44lbuhdciae.apps.googleusercontent.com"
                            onSuccess={this.responseGoogle}
                            onFailure={this.responseGoogle}
                            buttonText="Login with google"
                            className="btn btn-info col-sm-4 mr-1 mb-1"
                          /> 
                              <FacebookLogin
                            appId="2312267679062709"
                            autoLoad={false}
                            fields="name,email,picture"
                            onClick={this.responseFacebook}
                            callback={this.responseFacebook}
                            cssClass="btn btn-info col-sm-5 mr-1 mb-1"
                          />

                        </div>
                        <div className="form-group text-center">
                          <div className="col-sm-12">
                            <Link className="btn btn-link" to="/auth/registration">Registration</Link>
                            <Link className="btn btn-link" to="/auth/forgot-password">Forgot Password</Link>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
           
      );

    }
  }
}
const mapStatetoProps = (state) => {
  return {
    webLogin: state.headerReducer.webLogin, error: state.error
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onPostData: (a) => dispatch(postLogin(a))
  }
}

export default connect(mapStatetoProps, mapDispatchToProps)(Login);
