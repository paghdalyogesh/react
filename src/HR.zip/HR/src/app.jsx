import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import React, { Suspense, lazy } from 'react';
const LoginPage = lazy(() => import('./pages/login'));
const RegistrationPage = lazy(() => import('./pages/registration'));

const App = () => (
  <Router>
    <Suspense fallback={<div>Loading...</div>}>
      <Switch>
        <Route exact path="/" component={LoginPage}/>
        <Route path="/registration" component={RegistrationPage}/>
      </Switch>
    </Suspense>
  </Router>
);
export default App;

/*
import React, { Component } from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'

import Login from './pages/login'
import Registration from './pages/registration'
import ForgotPassword from './pages/forgot-password'
import ChangePassword from './pages/change-password'
import LogOut from './pages/log-out'
import Verify from './pages/verify'

class App extends Component {
  render() {
    return (
      <div className="App">
        <Router>
          <Switch>
            <Route exact={true} path='/auth/' component={Login} />
            <Route path='/auth/login' component={Login} />
            <Route path='/auth/registration' component={Registration} />
            <Route path='/auth/forgot-password' component={ForgotPassword} />
            <Route path='/auth/change-password' component={ChangePassword} />
            <Route path='/auth/log-out' component={LogOut} />
            <Route path='/auth/verify/:code' component={Verify} />
            <Route path='' component={Login} />
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
*/